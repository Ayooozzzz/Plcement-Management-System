package com.dimple.placement.model;

import jakarta.persistence.*;

@Entity
@Table(name= "users")
public class User {

	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    
    @Column(unique = true) 
    private String email;
    
    private String password;
    private String role;

    private String phone;
private String dob;
private String enrollment;
private String resume;




    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
        
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
public String getPhone() { return phone; }
public void setPhone(String phone) { this.phone = phone; }

public String getDob() { return dob; }
public void setDob(String dob) { this.dob = dob; }

public String getEnrollment() { return enrollment; }
public void setEnrollment(String enrollment) { this.enrollment = enrollment; }

public String getResume() { return resume; }
public void setResume(String resume) { this.resume = resume; }


    
}