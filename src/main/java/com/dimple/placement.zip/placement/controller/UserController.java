package com.dimple.placement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.dimple.placement.model.User;
import com.dimple.placement.repository.UserRepo;

@RestController
@CrossOrigin
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserRepo userRepo;

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        user.setPassword(user.getPassword()); 
        return userRepo.save(user);
    }

@PostMapping("/login")
public ResponseEntity<?> login(@RequestBody User user) {

    User existing = userRepo.findByEmail(user.getEmail());

    if (existing != null && existing.getPassword().equals(user.getPassword())) {
        return ResponseEntity.ok(existing);
    }

    return ResponseEntity.status(401).body("Invalid email or password");
}

@PutMapping("/update/{id}")
public User updateUser(@PathVariable Long id, @RequestBody User updatedUser) {

    User user = userRepo.findById(id).orElse(null);

    if (user == null) return null;

    user.setName(updatedUser.getName());
    user.setEmail(updatedUser.getEmail());
    user.setPhone(updatedUser.getPhone());
    user.setDob(updatedUser.getDob());
    user.setEnrollment(updatedUser.getEnrollment());
    user.setResume(updatedUser.getResume());

    return userRepo.save(user);


}
}